package com.navaplayer.model

data class Artist(
    val ONLINE_MP3: List<ONLINEMP3X>
)