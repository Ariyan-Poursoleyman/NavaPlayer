package com.navaplayer.model

data class Music(
    val ONLINE_MP3: List<ONLINEMP3>
)