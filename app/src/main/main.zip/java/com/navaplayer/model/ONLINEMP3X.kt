package com.navaplayer.model

data class ONLINEMP3X(
    val artist_image: String,
    val artist_image_thumb: String,
    val artist_name: String,
    val id: String
)