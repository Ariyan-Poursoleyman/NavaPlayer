package com.navaplayer.network

import com.navaplayer.model.Artist
import com.navaplayer.model.Music
import retrofit2.http.GET

interface ApiService  {
    @GET("api.php?latest")
    suspend fun getAllSongs(): Music

    @GET("api.php?artist_list")
    suspend fun artistList(): Artist
}