package com.navaplayer.view

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.navaplayer.databinding.ItemMusicBinding
import com.navaplayer.model.ONLINEMP3

class MusicAdapter(
    private var musicList: List<ONLINEMP3>,
    context: Context
) : RecyclerView.Adapter<MusicAdapter.MusicViewHolder>() {

    inner class MusicViewHolder(val binding: ItemMusicBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicViewHolder {
        val binding = ItemMusicBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MusicViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MusicViewHolder, position: Int) {
        val song = musicList[position]
        holder.binding.song = song
        holder.binding.executePendingBindings()
    }

    override fun getItemCount(): Int = musicList.size

    fun updateList(newList: List<ONLINEMP3>) {
        musicList = newList
        notifyDataSetChanged()
    }
}
