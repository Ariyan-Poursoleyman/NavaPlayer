package com.navaplayer.viewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.navaplayer.model.Artist
import com.navaplayer.repository.Repository
import kotlinx.coroutines.launch

class ArtistViewModel : ViewModel() {

    private val repository = Repository()

    // LiveData برای مشاهده لیست هنرمندان
    private val _hotArtists = MutableLiveData<Artist>()
    val hotArtists: LiveData<Artist> get() = _hotArtists

    // تابع فراخوانی API برای گرفتن لیست هنرمندان داغ
    fun fetchHotArtists() {
        viewModelScope.launch {
            try {
                val result = repository.getHotArtists()
                _hotArtists.value = result
            } catch (e: Exception) {
                // می‌تونی لاگ یا هندلینگ خطا اضافه کنی
                e.printStackTrace()
            }
        }
    }
}
